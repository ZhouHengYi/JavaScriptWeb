//
//  OCTWatchEvent.h
//  OctoKit
//
//  Created by Tyler Stromberg on 12/24/14.
//  Copyright (c) 2014 GitHub. All rights reserved.
//

#import "OCTEvent.h"

// A user starred a repository.
@interface OCTWatchEvent : OCTEvent

@end
